import Foundation

/**
 - Example in the book is for PC equipment
 - There's an `Equipment` abstract class(I think that's what it is?) at the top of the hierarchy
    that defines both shared methods and child management
    - Child management methods would return a failure/exception for their default implementation
        - Supports `leaf` subclasses which should **NOT** have child objects

 - The `leaf` or primitive / non-composite subclasses would inherit from `Equipment` directly and override the
    shared methods only
    - i.e. `class HardDrive: Equipment`
    - **No children**

 - A `Composite` subclass will be made from `Equipment` which will implement proper child object management methods
    - i.e. `class CompositeEquipment: Equipment`
 - Composite objects will subclass `CompositeEquipment`
    - i.e. `class Chassis: CompositeEquipment`
    - **Supports child object management**
    - Overridden methods are implemented with child objects in mind (Iteration)
 */

/**
 - To make this `Swifty`, this pattern could probably be implemented using protocols and structs instead of classes
 - For the `Component` protocol, this could be limited to the shared methods
 - A second protocol could be `CompositeComponent` and this can be reused for only child object management
    - Pros:
        - Only composite objects would conform to `CompositeComponent`
        - `CompositeComponent` protocol could be shared across multiple unrelated `Composite` structs across the app
        - `Leaf` would have no concept of children to manage so
            - intent is not muddied
 */

// MARK: Generic Protocols for Composite Pattern

protocol Component {
    var name: String { get set }
}

/// `Generic Where Clauses`
/// https://docs.swift.org/swift-book/LanguageGuide/Generics.html#ID192
protocol CompositeComponent {
    // TODO: Should there be a way to change the collection structure?
    var children: [Component] { get set }
    mutating func add(child: Component)
    mutating func remove(child: Component)
}

// MARK: Equipment example re-implementation

struct Watt { var amount: Int }
struct Currency { var cents: Int }

protocol Equipment: Component {
    func power() -> Watt
    func netPrice() -> Currency
    func discountPrice() -> Currency
}

struct HardDrive: Equipment {
    var name: String

    func power() -> Watt {
        return Watt(amount: 5)
    }

    func netPrice() -> Currency {
        return Currency(cents: 1000)
    }

    func discountPrice() -> Currency {
        return Currency(cents: 999)
    }
}

struct Chassis: Equipment, CompositeComponent {
    var name: String
    var children: [Component]

    func power() -> Watt {
        var netPower = Watt(amount: 0)
        for case let child as Equipment in children {
            netPower.amount += child.power().amount
        }
        return netPower
    }

    func netPrice() -> Currency {
        var netPrice = Currency(cents: 0)
        for case let child as Equipment in children {
            netPrice.cents += child.netPrice().cents
        }
        return netPrice
    }

    func discountPrice() -> Currency {
        var netDiscountedPrice = Currency(cents: 0)
        for case let child as Equipment in children {
            netDiscountedPrice.cents += child.discountPrice().cents
        }
        return netDiscountedPrice
    }

    mutating func add(child: Component) {
        children.append(child)
    }

    // TODO: Figure out how to write the child struct remove method
    mutating func remove<T: Component>(child: T) where T: Equatable {
        // get index
        if case let index = children.firstIndex(where: { $0 == child }) {

        }

        // remove from array
    }
}

